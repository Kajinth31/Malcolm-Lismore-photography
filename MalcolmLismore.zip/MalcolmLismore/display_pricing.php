<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "malcolm_lismore";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch pricing plans
$sql = "SELECT * FROM pricing_plans";
$result = $conn->query($sql);
$plans = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pricing Plans</title>
    <link rel="stylesheet" href="price1.css">
</head>
<body>

    <!-- Displaying pricing plans in a card layout -->
    <div class="pricing-table">
        <?php foreach ($plans as $plan): ?>
            <div class="card">
                <h2><?= htmlspecialchars($plan['plan_name']) ?></h2>
                <p class="price">$<?= number_format($plan['price'], 2) ?></p>
                <p><?= htmlspecialchars($plan['description']) ?></p>
                <ul>
                    <?php 
                    $features = explode(',', $plan['features']); 
                    foreach ($features as $feature): ?>
                        <li><?= htmlspecialchars(trim($feature)) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
    </div>

</body>
</html>
