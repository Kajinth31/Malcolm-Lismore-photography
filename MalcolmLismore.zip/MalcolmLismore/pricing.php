<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "malcolm_lismore";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch pricing plans
$sql = "SELECT * FROM pricing_plans";
$result = $conn->query($sql);
$plans = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pricing Plans</title>
    <link rel="stylesheet" href="price1.css">
    <div class="navbar">
            <div class="logo">Malcolum.</div>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="index.php #about-me" class="scroll-link">About</a></li>
                    <li><a href="contact_forms.php">Book Now</a></li>
                    <li><a href="Pricing.php">Pricing</a></li>
                    <li class="dropdown">
                        <a href="gallery_wedding.php">Gallery</a>
                        <ul class="dropdown-content">
                            <li><a href="wildlife.php">Wildlife</a></li>
                            <li><a href="portrait.php">Portrait</a></li>
                            <li><a href="gallery_birthday.php">Birthday</a></li>
                            <li><a href="gallery_wedding.php">Wedding</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
            <div class="sign-in-container">
            <a href="home.php">
            <button class="sign-in">Sign In</button>
            </a>
            </div>
        </div>
</head>
<body>

    <!-- Displaying pricing plans in a card layout -->
    <div class="pricing-table">
        <?php foreach ($plans as $plan): ?>
            <div class="card">
                <h2><?= htmlspecialchars($plan['plan_name']) ?></h2>
                <p class="price">$<?= number_format($plan['price'], 2) ?></p>
                <p><?= htmlspecialchars($plan['description']) ?></p>
                <ul>
                    <?php 
                    $features = explode(',', $plan['features']); 
                    foreach ($features as $feature): ?>
                        <li><?= htmlspecialchars(trim($feature)) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
