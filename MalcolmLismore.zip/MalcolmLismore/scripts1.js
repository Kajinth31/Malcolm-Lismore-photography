document.addEventListener('DOMContentLoaded', function () {
    const filters = document.querySelectorAll('.gallery-navigation a');
    const items = document.querySelectorAll('.gallery-item');
    function showCategory(category) {
        // Display the category in an alert box
        alert("Category: " + category);
    
        // Alternatively, display the category in the HTML element with id="category-display"
        document.getElementById('category-display').textContent = "Selected Category: " + category;
    }
    

    filters.forEach(filter => {
        filter.addEventListener('click', function (e) {
            e.preventDefault();
            const filterValue = this.getAttribute('data-filter');

            // Remove 'active' class from all filters
            filters.forEach(f => f.classList.remove('active'));
            // Add 'active' class to the clicked filter
            this.classList.add('active');

            // Loop through all items
            items.forEach(item => {
                // If 'all' filter is selected or item's category matches the filter, show the item
                if (filterValue === 'all' || item.getAttribute('data-category') === filterValue) {
                    item.style.display = 'block';
                } else {
                    // Otherwise, hide the item
                    item.style.display = 'none';
                }
            });
        });
    });
});
