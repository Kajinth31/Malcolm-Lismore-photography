<?php
 // Include the navigation bar

// Fetch the booking data from the contact_details table
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "malcolm_lismore";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch event names and counts
$sqlEventName = "SELECT event_name, COUNT(*) as count FROM contact_details GROUP BY event_name";
$resultEventName = $conn->query($sqlEventName);
$eventNames = [];
$eventCounts = [];

if ($resultEventName && $resultEventName->num_rows > 0) {
    while ($row = $resultEventName->fetch_assoc()) {
        $eventNames[] = $row['event_name'];
        $eventCounts[] = $row['count'];
    }
}

// Query to fetch event locations and counts
$sqlEventLocation = "SELECT location, COUNT(*) as count FROM contact_details GROUP BY location";
$resultEventLocation = $conn->query($sqlEventLocation);
$eventLocations = [];
$locationCounts = [];

if ($resultEventLocation && $resultEventLocation->num_rows > 0) {
    while ($row = $resultEventLocation->fetch_assoc()) {
        $eventLocations[] = $row['location'];
        $locationCounts[] = $row['count'];
    }
}

// Query to fetch event dates
$sqlEventDate = "SELECT event_date, COUNT(*) as count FROM contact_details GROUP BY event_date";
$resultEventDate = $conn->query($sqlEventDate);
$eventDates = [];
$dateCounts = [];

if ($resultEventDate && $resultEventDate->num_rows > 0) {
    while ($row = $resultEventDate->fetch_assoc()) {
        $eventDates[] = $row['event_date'];
        $dateCounts[] = $row['count'];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="sheet.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>        

<div class="container">
        <!-- Navigation Bar -->
        <div class="nav-bar">
            <h2>Admin Dashboard</h2>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="manage_images.php">Manage Images</a></li>
                <li><a href="manage_pricing.php">Manage Pricing Plans</a></li>
                <li><a href="contact_details.php">Contact Details</a></li>
            </ul>
            <div class="logout-button">
                <a href="login.php">Logout</a>
            </div>
        </div>
        <div class="content">


        
        <div class="content">
        <h1>Event Statistics</h1>
            <section>
                
                <div class="chart-container">
                    <canvas id="eventNameChart"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="eventLocationChart"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="eventDateChart"></canvas>
                </div>
            </section>
        </div>
    </div>

    <script>
        // Event Name Chart
        const eventNameCtx = document.getElementById('eventNameChart').getContext('2d');
        const eventNameChart = new Chart(eventNameCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($eventNames); ?>,
                datasets: [{
                    label: 'Events by Name',
                    data: <?php echo json_encode($eventCounts); ?>,
                    backgroundColor: '#007bff',
                    borderColor: '#0056b3',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Event Location Chart
        const eventLocationCtx = document.getElementById('eventLocationChart').getContext('2d');
        const eventLocationChart = new Chart(eventLocationCtx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($eventLocations); ?>,
                datasets: [{
                    label: 'Events by Location',
                    data: <?php echo json_encode($locationCounts); ?>,
                    backgroundColor: [
                        '#007bff',
                        '#28a745',
                        '#dc3545',
                        '#ffc107',
                        '#17a2b8'
                    ],
                    borderColor: '#fff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                }
            }
        });

        // Event Date Chart
        const eventDateCtx = document.getElementById('eventDateChart').getContext('2d');
        const eventDateChart = new Chart(eventDateCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($eventDates); ?>,
                datasets: [{
                    label: 'Events by Date',
                    data: <?php echo json_encode($dateCounts); ?>,
                    backgroundColor: 'rgba(0, 123, 255, 0.5)',
                    borderColor: '#007bff',
                    borderWidth: 2,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
