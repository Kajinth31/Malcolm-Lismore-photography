function confirmDelete() {
    return confirm("Are you sure you want to delete this item?");
}

function editImage(id, category, description) {
    document.getElementById('image_id').value = id;
    document.getElementById('category').value = category;
    document.getElementById('description').value = description;
    document.getElementById('image').required = false; // Don't require a new image file for editing
}

function editPlan(id, plan_name, description, price, features) {
    document.getElementById('plan_id').value = id;
    document.getElementById('plan_name').value = plan_name;
    document.getElementById('description').value = description;
    document.getElementById('price').value = price;
    document.getElementById('features').value = features;
}

// Smooth Scrolling Functionality
document.querySelectorAll('.scroll-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        const targetId = this.getAttribute('href').substring(1);
        const targetElement = document.getElementById(targetId);
        
        const targetPosition = targetElement.offsetTop;
        const startPosition = window.pageYOffset;
        const distance = targetPosition - startPosition;
        const duration = 2000; // Duration in milliseconds
        let start = null;

        window.requestAnimationFrame(step);

        function step(timestamp) {
            if (!start) start = timestamp;
            const progress = timestamp - start;
            const easeInOutCubic = progress / duration - 1;
            window.scrollTo(0, startPosition + distance * (easeInOutCubic * easeInOutCubic * easeInOutCubic + 1));
            if (progress < duration) {
                window.requestAnimationFrame(step);
            }
        }
    });
});