<?php
include 'nav.php'; // Include the navigation bar

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "malcolm_lismore";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle pricing plans
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['plan_name'])) {
    $planName = $_POST['plan_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $features = $_POST['features'];

    if (isset($_POST['plan_id']) && !empty($_POST['plan_id'])) {
        $planId = $_POST['plan_id'];
        $stmt = $conn->prepare("UPDATE pricing_plans SET plan_name=?, description=?, price=?, features=? WHERE id=?");
        $stmt->bind_param("ssdsi", $planName, $description, $price, $features, $planId);
    } else {
        $stmt = $conn->prepare("INSERT INTO pricing_plans (plan_name, description, price, features) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssds", $planName, $description, $price, $features);
    }
    if ($stmt->execute()) {
        header("Location: manage_pricing.php?plan_success=1");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Handle plan deletion
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['delete_plan'])) {
    $id = $_GET['delete_plan'];
    $stmt = $conn->prepare("DELETE FROM pricing_plans WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        header("Location: manage_pricing.php?delete_success=1");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch pricing plans
$sql = "SELECT * FROM pricing_plans";
$result = $conn->query($sql);
$plans = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
}

$conn->close();
?>

<section>
    <h2>Manage Pricing Plans</h2>
    <form id="pricing-form" action="manage_pricing.php" method="post">
        <input type="hidden" name="plan_id" id="plan_id">
        <label for="plan_name">Plan Name:</label>
        <input type="text" name="plan_name" id="plan_name" required>

        <label for="description">Description:</label>
        <textarea name="description" id="description" required></textarea>

        <label for="price">Price:</label>
        <input type="number" name="price" id="price" step="0.01" required>

        <label for="features">Features (comma-separated):</label>
        <textarea name="features" id="features" required></textarea>

        <button type="submit">Save Plan</button>
    </form>

    <div id="pricing-table">
        <h3>Pricing Plans</h3>
        <table>
            <tr>
                <th>Plan Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Features</th>
                <th>Action</th>
            </tr>
            <?php foreach ($plans as $plan): ?>
                <tr>
                    <form action="manage_pricing.php" method="post">
                        <td><input type="text" name="plan_name" value="<?= htmlspecialchars($plan['plan_name']) ?>" required></td>
                        <td><textarea name="description" required><?= htmlspecialchars($plan['description']) ?></textarea></td>
                        <td><input type="number" name="price" value="<?= number_format($plan['price'], 2) ?>" step="0.01" required></td>
                        <td><textarea name="features" required><?= htmlspecialchars($plan['features']) ?></textarea></td>
                        <td>
                            <input type="hidden" name="plan_id" value="<?= $plan['id'] ?>">
                            <button type="submit">Save</button>
                            <a href="manage_pricing.php?delete_plan=<?= $plan['id'] ?>" class="delete-button" onclick="return confirm('Are you sure you want to delete this plan?')">Delete</a>
                        </td>
                    </form>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</section>

<?php include 'footer.php'; // Close the layout ?>
