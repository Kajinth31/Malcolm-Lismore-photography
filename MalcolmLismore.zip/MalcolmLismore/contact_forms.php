<?php
// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection parameters
    $servername = "localhost";  // Your database server
    $username = "root";  // Your database username
    $password = "";  // Your database password
    $dbname = "malcolm_lismore";  // Your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO contact_details (name, phone, email, location, event_date, event_name, inquiry) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $phone, $email, $location, $event_date, $event_name, $inquiry);

    // Set parameters and execute
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $location = $_POST['location'];
    $event_date = $_POST['event_date'];
    $event_name = $_POST['event_name'];
    $inquiry = $_POST['inquiry'];

    if ($stmt->execute()) {
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form</title>
    <link rel="stylesheet" href="contact_style.css">
</head>
<body>
    <header>
    <header>
    <?php
    include 'nav.html'; // This will insert the contents of header.html here
    ?>
    </header>

    <div class="container">
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <h2>Contact Us</h2>
            <label for="name">Name:</label><br>
            <input type="text" id="name" name="name" required><br><br>

            <label for="phone">Phone:</label><br>
            <input type="text" id="phone" name="phone" required><br><br>

            <label for="email">Email:</label><br>
            <input type="email" id="email" name="email" required><br><br>

            <label for="location">Location:</label><br>
            <input type="text" id="location" name="location" required><br><br>

            <label for="event_date">Event Date:</label><br>
            <input type="date" id="event_date" name="event_date" required><br><br>

            <label for="event_name">Event Name:</label><br>
            <select id="event_name" name="event_name" required>
                <option value="Wedding">Wedding</option>
                <option value="Birthday">Birthday</option>
                <option value="Portrait">Portrait</option>
                <option value="Wildlife">Wildlife</option>
            </select><br><br>

            <label for="inquiry">Inquiry:</label><br>
            <textarea id="inquiry" name="inquiry" rows="5" required></textarea><br><br>

            <input type="submit" value="Submit">
        </form>
    </div>
</body>
</html>
