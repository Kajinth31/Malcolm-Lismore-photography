<?php
// Start the session
session_start();

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "malcolm_lismore";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle login form submission
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prevent SQL injection
    $username = $conn->real_escape_string($username);
    $password = $conn->real_escape_string($password);

    // Fetch the user from the database
    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // User exists, log them in
        $_SESSION['username'] = $username;
        header("Location: home.php"); // Redirect to a dashboard or another page
        exit();
    } else {
        $error = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Arial', sans-serif;
}

body, html {
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #13072e;
}

/* Logout button styles */
.logout-button {
    position: fixed;
    top: 20px;
    left: 20px;
}

.logout-button a {
    padding: 10px 20px;
    background-color: #1673b3;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-size: 16px;
    transition: background 0.3s ease, transform 0.3s ease;
}

.logout-button a:hover {
    background-color: #0e5a8a;
    transform: scale(1.05);
}

.container {
    display: flex;
    width: 80%;
    max-width: 1200px;
    height: 80vh;
    box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.2);
    border-radius: 10px;
}

.left {
    flex: 1;
    background-color: white;
    display: flex;
    justify-content: center;
    align-items: center;
}

.left img {
    width: 90%;
    height: auto;
}

.right {
    flex: 1;
    background: linear-gradient(135deg, #13072e, #3f2182);
    padding: 50px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
    color: white;
    border-top-right-radius: 10px;
    border-bottom-right-radius: 10px;
}

h1 {
    font-size: 36px;
    margin-bottom: 30px;
}

form {
    width: 100%;
    display: flex;
    flex-direction: column;
}

label {
    font-size: 18px;
    margin-bottom: 5px;
}

input {
    padding: 15px;
    margin-bottom: 20px;
    font-size: 16px;
    border-radius: 5px;
    border: none;
    width: 100%;
}

button {
    padding: 15px;
    background: linear-gradient(90deg, #43cea2, #185a9d);
    color: white;
    font-size: 18px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s ease;
}

button:hover {
    background: linear-gradient(90deg, #36d1dc, #5b86e5);
}

.error {
    color: #ff6b6b;
    margin-bottom: 20px;
}

    </style>
</head>
<body>
<div class="logout-button">
                <a href="index.php">home</a>
            </div>
    <div class="container">
        <div class="left">
            <img src="l1.png" alt="Illustration">
        </div>
        <div class="right">
            <h1>Welcome Back!</h1>

            <?php if (!empty($error)): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>

            <form action="login.php" method="POST">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>

                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>

                <button type="submit">Login</button>
            </form>
        </div>
    </div>
</body>
</html>
