<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "malcolm_lismore";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch wedding images
$sql = "SELECT image_path FROM images WHERE category = 'portrait'";
$result = $conn->query($sql);

$images = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $images[] = $row['image_path'];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wedding Gallery</title>
    <link rel="stylesheet" href="gallery1.css">
</head>
<body>
        <?php
    // Include the HTML header
        include 'nav.html'; // This will insert the contents of header.html here
        ?>

<h2>portrait Gallery</h2>

<div class="gallery-container">
    <?php foreach ($images as $image): ?>
        <div class="gallery-item">
            <img src="<?php echo htmlspecialchars($image); ?>" alt="portrait Image">
        </div>
    <?php endforeach; ?>
</div>
<br>
</body>
</html>
