<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern Audio Speaker</title>
    <link rel="stylesheet" href="about.css">
</head>
<body>
    <header>
    <?php
// Include the HTML header
    include 'nav.html'; // This will insert the contents of header.html here
    ?>
    </header>

    <section class="hero">
        <div class="lap">
    <img src="m.png" alt="Person with a Camera">
        </div>
        <div class="content">
            <h1>Malcolum lismore</h1>
            <div class="subtitle">Photography</div>
            <p>Welcome to Malcoum lismore Photogaphy where every moment becomes a timeless memory. Explore our portfolio and let us capture the beauty of your special occasions with passion and creativity.</p>
            <li><a href="#about-me" class="buy-now scroll-link">Book Now</a></li>
        </div>
    </section>

    <!-- About Me Section -->
    <section id="about-me" class="about-me-section">
        <div class="about-me-container">
            <div class="about-me-image">
                <img src="p1.jpg" alt="Person with a Camera">
            </div>
            <div class="about-me-content">
                <h2>About Me</h2>
                <h3>Welcome to Malcolm Lismore Photography</h3>
                <p>Capturing the Natural Beauty of Scotland <br><br>Malcolm Lismore is a passionate freelance photographer based on the stunning Northwest coast of Scotland. Specializing in breathtaking landscapes, natural wildlife, and coastal birds, Malcolm's work brings the rugged beauty of Scotland to life. His photography extends beyond nature, offering professional services for weddings, portraits, and special events.</p>
                <blockquote class="about-me-quote">
                "Malcolm's lens captures the essence of Scotland's wilderness, from its dramatic landscapes to its captivating wildlife. His dedication to photography shines through every image, creating timeless memories for all occasions."
                </blockquote>
                <p>Whether you're looking to adorn your space with the serene beauty of Scotland or seeking a photographer to immortalize your special moments, Malcolm Lismore Photography promises artistry, passion, and unforgettable imagery.</p>
                </div>
            </div>
        </div>
    </section>
    <script src="scripts.js"></script>
</body>
</html>
