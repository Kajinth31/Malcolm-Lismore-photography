<?php
include 'nav.php'; // Include the navigation bar

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "malcolm_lismore";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle contact deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_contact'])) {
    $contactId = $_POST['contact_id'];
    $stmt = $conn->prepare("DELETE FROM contact_details WHERE id = ?");
    $stmt->bind_param("i", $contactId);
    if ($stmt->execute()) {
        header("Location: contact_details.php?delete_success=1");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch contact details
$sql = "SELECT * FROM contact_details";
$result = $conn->query($sql);
$contacts = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $contacts[] = $row;
    }
}

$conn->close();
?>

<section>
    <h2>Contact Details</h2>
    <div id="contact-table">
        <table>
            <tr>
                <th>Name</th>
                <th>Phone Number</th>
                <th>Email</th>
                <th>Location</th>
                <th>Event Date</th>
                <th>Event Name</th>
                <th>Enquiry</th>
                <th>Action</th> <!-- New Action column -->
            </tr>
            <?php foreach ($contacts as $contact): ?>
                <tr>
                    <td><?= htmlspecialchars($contact['name']) ?></td>
                    <td><?= htmlspecialchars($contact['phone']) ?></td>
                    <td><?= htmlspecialchars($contact['email']) ?></td>
                    <td><?= htmlspecialchars($contact['location']) ?></td>
                    <td><?= htmlspecialchars($contact['event_date']) ?></td>
                    <td><?= htmlspecialchars($contact['event_name']) ?></td>
                    <td><?= htmlspecialchars($contact['inquiry']) ?></td>
                    <td>
                        <form action="contact_details.php" method="post" style="display:inline-block;">
                            <input type="hidden" name="contact_id" value="<?= $contact['id'] ?>">
                            <input type="hidden" name="delete_contact" value="1">
                            <button type="submit" onclick="return confirm('Are you sure you want to delete this contact?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</section>

<?php include 'footer.php'; // Close the layout ?>
