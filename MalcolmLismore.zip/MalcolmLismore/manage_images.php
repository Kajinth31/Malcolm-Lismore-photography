<?php
include 'nav.php'; // Include the navigation bar

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "malcolm_lismore";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle image upload/edit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['category'])) {
    $category = $_POST['category'];
    $description = $_POST['description'] ?? '';
    $imageId = $_POST['image_id'] ?? null;

    // Check if an image file is uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $image = $_FILES['image'];
        $imagePath = 'uploads/' . basename($image['name']);
        if (move_uploaded_file($image['tmp_name'], $imagePath)) {
            // If editing an existing image, update it
            if (!empty($imageId)) {
                $stmt = $conn->prepare("UPDATE images SET image_path=?, category=?, description=? WHERE id=?");
                $stmt->bind_param("sssi", $imagePath, $category, $description, $imageId);
            } else {
                // Otherwise, insert a new image record
                $stmt = $conn->prepare("INSERT INTO images (image_path, category, description) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $imagePath, $category, $description);
            }

            if ($stmt->execute()) {
                header("Location: manage_images.php?upload_success=1");
                exit();
            } else {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Error uploading file.";
        }
    } elseif (!empty($imageId)) {
        // If no new image is uploaded, but it's an edit, just update the description and category
        $stmt = $conn->prepare("UPDATE images SET category=?, description=? WHERE id=?");
        $stmt->bind_param("ssi", $category, $description, $imageId);

        if ($stmt->execute()) {
            header("Location: manage_images.php?upload_success=1");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Please select an image to upload.";
    }
}

// Handle image deletion
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['delete_image'])) {
    $id = $_GET['delete_image'];
    $stmt = $conn->prepare("DELETE FROM images WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        header("Location: manage_images.php?delete_success=1");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch images
$sql = "SELECT * FROM images";
$result = $conn->query($sql);
$images = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $images[] = $row;
    }
}

$conn->close();
?>
<section>
    <h2>Manage Images</h2>
    <!-- Main form for new uploads -->
    <form id="image-form" action="manage_images.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="image_id" id="image_id">
        <label for="category">Category:</label>
        <select name="category" id="category">
            <option value="wedding">Wedding</option>
            <option value="birthday">Birthday</option>
            <option value="portrait">Portrait</option>
            <option value="wildlife">Wildlife</option>
        </select>
        <label for="image">Select Image:</label>
        <input type="file" name="image" id="image" required>
        <label for="description">Description:</label>
        <input type="text" name="description" id="description" placeholder="Add a description...">
        <button type="submit">Upload Image</button>
    </form>

    <div id="image-tables">
        <?php foreach (['wedding', 'birthday', 'portrait', 'wildlife'] as $category): ?>
            <h3><?= ucfirst($category) ?> Images</h3>
            <table>
                <tr>
                    <th>Image</th>
                    <th>Description</th>
                    <th>Category</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($images as $image): ?>
                    <?php if ($image['category'] === $category): ?>
                        <tr>
                            <td><img src="<?= $image['image_path'] ?>" width="100"></td>
                            <td><?= htmlspecialchars($image['description']) ?></td>
                            <td><?= ucfirst($image['category']) ?></td>
                            <td>
                                <form action="manage_images.php" method="post" enctype="multipart/form-data" style="display:inline-block;">
                                    <input type="hidden" name="image_id" value="<?= $image['id'] ?>">
                                    <input type="text" name="description" value="<?= htmlspecialchars($image['description']) ?>" placeholder="Description">
                                    <select name="category">
                                        <option value="wedding" <?= $image['category'] === 'wedding' ? 'selected' : '' ?>>Wedding</option>
                                        <option value="birthday" <?= $image['category'] === 'birthday' ? 'selected' : '' ?>>Birthday</option>
                                        <option value="portrait" <?= $image['category'] === 'portrait' ? 'selected' : '' ?>>Portrait</option>
                                        <option value="wildlife" <?= $image['category'] === 'wildlife' ? 'selected' : '' ?>>Wildlife</option>
                                    </select>
                                    <input type="file" name="image">
                                    <button type="submit">Save</button>
                                </form>
                                <a href="manage_images.php?delete_image=<?= $image['id'] ?>" class="delete-button" onclick="return confirm('Are you sure you want to delete this image?')">Delete</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            </table>
        <?php endforeach; ?>
    </div>
</section>

<?php include 'footer.php'; // Close the layout ?>
